package com.axis.security.services;

import java.math.BigDecimal;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.axis.models.User;
import com.axis.repository.UserRepository;

@Service
public class CustomerServiceImpl {
	@Autowired
	UserRepository customerRepository;

	public User signUp(User customer) {
        
      
        
        customer.setAccountNumber(generateAccountNumber());
        customer.setBalance(new BigDecimal("100"));
        return customerRepository.save(customer);
	}
	private String generateAccountNumber() {
		  
	    Random random = new Random();
	    StringBuilder accountNumber = new StringBuilder();
	    for (int i = 0; i < 12; i++) {
	        accountNumber.append(random.nextInt(10));
	    }
	    return accountNumber.toString();
	}
}
