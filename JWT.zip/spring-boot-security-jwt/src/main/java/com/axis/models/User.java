package com.axis.models;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;


@Entity
@Table(name = "users", 
    uniqueConstraints = { 
      @UniqueConstraint(columnNames = "username"),
      @UniqueConstraint(columnNames = "email") 
    })
public class User {
	@Id
    @SequenceGenerator(name = "customerId", allocationSize = 1,initialValue =100000000)
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "customerId")
	private Long customerId;

  private String username;

  private String email;

  private String password;

  private String accountNumber;
  private BigDecimal balance;
	
  @ManyToMany(fetch = FetchType.LAZY)
  @JoinTable(  name = "user_roles", 
        joinColumns = @JoinColumn(name = "customerId"), 
        inverseJoinColumns = @JoinColumn(name = "role_id"))
  private Set<Role> roles = new HashSet<>();

  

  public User() {
	super();
	// TODO Auto-generated constructor stub
}

  
public User( String username, String email,
		 String password) {
	super();
	this.username = username;
	this.email = email;
	this.password = password;
}



public long getCustomerId() {
	return customerId;
}


public void setCustomerId(long customerId) {
	this.customerId = customerId;
}


public String getAccountNumber() {
	return accountNumber;
}


public void setAccountNumber(String accountNumber) {
	this.accountNumber = accountNumber;
}


public BigDecimal getBalance() {
	return balance;
}


public void setBalance(BigDecimal balance) {
	this.balance = balance;
}


public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public Set<Role> getRoles() {
    return roles;
  }

  public void setRoles(Set<Role> roles) {
    this.roles = roles;
  }
}
