import React from 'react'
import { Link, NavLink } from 'react-router-dom'

const Navbar = () => {
  return (
    <>
   <div>
    <nav class="navbar navbar-expand-lg navbar-light bg-primary">
    <div class="container-fluid">
    <div class="collapse navbar-collapse" id="navbarText">
    <a className="navbar-brand text-white" href="/"><i class="fa-solid fa-list"></i> Bank App</a>
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        
        <li class="nav-item">
        <Link to="/" className="nav-link active text-white" ><i className="fa-solid fa-right-to-bracket"></i>Home</Link>
        </li>
        <li class="nav-item">
          <a class="nav-link active text-white" aria-current="page">About Us</a>
        </li>
      </ul>
      <div class="navbar-text">
      <Link to="login" className="nav-link active text-white" ><i className="fa-solid fa-right-to-bracket"></i> LOGIN</Link>
      </div>
      <div class="navbar-text ">
      <Link to="signup" className="nav-link active text-white" ><i className="fa-solid fa-right-to-bracket"></i> REGISTER</Link>
      </div>
    </div>
  </div>
  
</nav>

</div>

</>
  )
}

export default Navbar