
import { Link, useNavigate, useParams } from "react-router-dom";

const Login = () => {
  
  return (
    <div
      className="container-fluid p-5 bg-img"
      style={{
        backgroundImage: "url(img/back2.jpg)",
        backgroundPosition: "center",
        backgroundSize: "cover",
        backgroundRepeat: "no-repeat",
      }}
    >
      <div className="row">
        <div className="col-md-5 offset-md-3">
          <div className="card paint-card">
            <div className="card-header ">
              <h4 className="text-dark text-center">Login</h4>
              
            </div>
            <div className="card-body">
              <form >
                <div className="mb-3">
                  <label className="form-label">Customer Id</label>
                  <input
                    type="number"
                    className="form-control"
                    name="email"
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Password</label>
                  <input
                    type="password"
                    className="form-control"
                    
                    name="password"
                  />
                </div>

                <button type="submit"  className="btn btn-primary col-md-12">
                  Login
                </button>
                <Link to="/account" className="text-decoration-none ms-2">
                login
              </Link>
              </form>
            </div>
            <div className="card-footer bg-white text-center p-3">
              Don't have account
              <Link to="/signup" className="text-decoration-none ms-2">
                register
              </Link>
              <br />
            </div>
          </div>
        </div>
      </div>
      
    </div>
  );
};

export default Login;
