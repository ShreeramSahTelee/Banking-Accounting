import React from "react";



const TransferFund = () => {
  return (
    <>
      <div className="row p-2">
        <p class="text-center fs-1" id="adminHead">Fund Transfer</p>
        <div class="col-md-6 cardx">
          <a class="text-decoration-none bg-custom">
            <div class="card paint-card">
              <div class="card-body text-center">
                <i class="bi bi-journal-check fa-2x"></i>
                <br />
                <p class="fs-3 text-dark"> Balance is :</p>
                <p class="fs-3 text-dark"></p>
              </div>
            </div>
          </a>
        </div>
        <div class="col-md-6">
          <a class="text-decoration-none bg-custom">
            <button type="button" class="btn btn-primary btn-lg btn-block">Deposit Fund</button><br></br><br></br>
            <button type="button" class="btn btn-primary btn-lg btn-block">Transfer Fund</button>
          </a>
        </div>
      </div>
    </>
  )
}
export default TransferFund;