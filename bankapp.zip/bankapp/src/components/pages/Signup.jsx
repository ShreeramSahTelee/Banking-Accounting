
import { Link } from "react-router-dom";

const Signup = () => {
  
  return (
    <div
      className="container-fluid p-2"
      style={{
        backgroundPosition: "center",
        backgroundSize: "cover",
        backgroundRepeat: "no-repeat",
      }}
    >
      <div className="row">
        <div className="col-md-6 offset-md-3">
          <div className="card paint-card">
            <div className="card-header">
              <h3 className="text-center text-dark">Open your Account</h3>
            </div>
            <div className="card-body">
              <form>
                
                <div className="row">
                  <div className="col">
                    <label>Email Id</label>
                    <input
                      type="email"
                      name="enter email"
                      required
                      className="form-control form-control-sm"
                     
                    />
                  </div>
                </div>
                
                  <div className="col">
                    <label>Mobile No</label>
                    <input
                      type="number"
                      name="mobNo"
                      required
                      maxLength={10}
                      minLength={10}
                      className="form-control form-control-sm"
                      
                    />
                  </div>
                

                <div className="row mt-3">
                  <div className="col">
                    <label>Password</label>
                    <input
                      type="password"
                      name="password"
                      required
                      id="psw"
                      className="form-control form-control-sm"
                     
                    />
                  </div>
                </div>


                <div className="text-center mt-3">
                  <button className="btn btn-primary col-md-12">
                    Register
                  </button>
                </div>
              </form>
              
            </div>
          </div>
        </div>
      </div>
      
    </div>
  );
};

export default Signup;
