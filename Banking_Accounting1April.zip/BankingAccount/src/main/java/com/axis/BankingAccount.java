package com.axis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankingAccount {

	public static void main(String[] args) {
		SpringApplication.run(BankingAccount.class, args);
	}

}
